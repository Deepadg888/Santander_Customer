#clearing objects
rm(list=ls(all=T))

#loading required libraries
library(tidyverse)
library(moments)
library(DataExplorer)
library(caret)
library(Matrix)
library(pdp)
library(mlbench)
library(caTools)
library(randomForest)
library(glmnet)
library(mlr)
library(vita)
library(rBayesianOptimization)
library(pROC)
library(DMwR)
library(ROSE)
library(yardstick)
library(DataCombine)
library(ggplot2)
library(dplyr)
library(maps)
library(mongolite)
library(lubridate)
library(gridExtra)


#set working directory
setwd("D:/Rpractice")

#Importing training data
#loading data
df_train = read.csv("train.csv",header = T,sep=",")
df_test = read.csv("test.csv",header = T,sep=",")
#Dimention of train data
dim(df_train)

#summary of the train dataset
str(df_train)

#type casting the target variable
df_train$target=as.factor(df_train$target)

#Target class count in train data
table(df_train$target)

#Percentage count of target class in train data
table(df_train$target)/length(df_train$target)*100

#Bar plot for count of target class in train data
plot1=ggplot(df_train,aes(target))+theme_bw()+geom_bar(stat = 'count',fill='lightgreen')

#violin with jitter plots for target classes
plot2 = ggplot(df_train,aes(x=target,y=1:nrow(df_train)))+theme_bw()+geom_violin(fill='lightblue')+
  facet_grid(df_train$target)+geom_jitter(width = 0.02)+labs(y='Index')
grid.arrange(plot1,plot2,ncol=2)

#We are having a unbalnced data, where 90% of the data is no. of customers who will not make a transaction & 10% of the data are those who will make a transaction.

#distribution of train attributes from 3 to 102
for (var in names(df_train)[c(3:102)]) {
  target=df_train$target
  Plot=ggplot(df_train,aes(df_train[[var]],fill=target))+
    geom_density(kernel='gaussian')+ggtitle(var)+theme_classic()
  print(Plot)
}

#distribution of train attributes from 103 to 202
for (var in names(df_train)[c(103:202)]) {
  target=df_train$target
  Plot=ggplot(df_train,aes(df_train[[var]],fill=target))+
    geom_density(kernel='gaussian')+ggtitle(var)+theme_classic()
  print(Plot)
}


#dimension of test dataset
dim(df_test)

#distribution of test attributes from 2 to 101
plot_density(df_test[,c(2:101)],ggtheme=theme_classic(),geom_density_args=list(color='red'))

#distribution of test attributes from 102 to 201
plot_density(df_test[,c(102:201)],ggtheme=theme_classic(),geom_density_args=list(color='red'))

#Mean value per rows and columns in train and test dataset
#applying the function to find mean values per row in train and test
train_mean = apply(df_train[,-c(1,2)],MARGIN = 1, FUN = mean)
test_mean = apply(df_test[,-c(1)],MARGIN = 1, FUN = mean)
ggplot()+
  geom_density(data = df_train[,-c(1,2)],aes(x=train_mean),kernel='gaussian',show.legend = TRUE,color='blue')+theme_classic()+
  geom_density(data = df_test[,-c(1)],aes(x=test_mean),kernel='gaussian',show.legend = TRUE,color='green')+
  labs(x='mean values per row',title = "Distribution of mean values per row in train and test dataset")

#applying the function to find mean values per column in train and test
train_mean = apply(df_train[,-c(1,2)],MARGIN = 2, FUN = mean)
test_mean = apply(df_test[,-c(1)],MARGIN = 2, FUN = mean)
ggplot()+
  geom_density(aes(x=train_mean),kernel='gaussian',show.legend = TRUE,color='blue')+theme_classic()+
  geom_density(aes(x=test_mean),kernel='gaussian',show.legend = TRUE,color='green')+
  labs(x='mean values per column',title = "Distribution of mean values per column in train and test dataset")

#applying the function to find standard diviation values per row in train and test
train_sd = apply(df_train[,-c(1,2)],MARGIN = 1, FUN = sd)
test_sd = apply(df_test[,-c(1)],MARGIN = 1, FUN = sd)
ggplot()+
  geom_density(data = df_train[,-c(1,2)],aes(x=train_sd),kernel='gaussian',show.legend = TRUE,color='red')+theme_classic()+
  geom_density(data = df_test[,-c(1)],aes(x=test_sd),kernel='gaussian',show.legend = TRUE,color='blue')+
  labs(x='sd values per row',title = "Distribution of sd values per row in train and test dataset")

#applying the function to find standard diviation values per column in train and test
train_sd = apply(df_train[,-c(1,2)],MARGIN = 2, FUN = sd)
test_sd = apply(df_test[,-c(1)],MARGIN = 2, FUN = sd)
ggplot()+
  geom_density(aes(x=train_sd),kernel='gaussian',show.legend = TRUE,color='red')+theme_classic()+
  geom_density(aes(x=test_sd),kernel='gaussian',show.legend = TRUE,color='blue')+
  labs(x='sd values per column',title = "Distribution of sd values per column in train and test dataset")

#applying the function to find skewness values per row in train and test
train_skew = apply(df_train[,-c(1,2)],MARGIN = 1, FUN = skewness)
test_skew = apply(df_test[,-c(1)],MARGIN = 1, FUN = skewness)
ggplot()+
  geom_density(aes(x=train_skew),kernel='gaussian',show.legend = TRUE,color='green')+theme_classic()+
  geom_density(aes(x=test_skew),kernel='gaussian',show.legend = TRUE,color='blue')+
  labs(x='skewness values per row',title = "Distribution of skewness values per row in train and test dataset")

#applying the function to find skewness values per column in train and test
train_skew = apply(df_train[,-c(1,2)],MARGIN = 2, FUN = skewness)
test_skew = apply(df_test[,-c(1)],MARGIN = 2, FUN = skewness)
ggplot()+
  geom_density(aes(x=train_skew),kernel='gaussian',show.legend = TRUE,color='green')+theme_classic()+
  geom_density(aes(x=test_skew),kernel='gaussian',show.legend = TRUE,color='blue')+
  labs(x='skewness values per row',title = "Distribution of skewness values per column in train and test dataset")


#Missing value analysis
#Finding missing value in train data
missing_val=data.frame(missing_val=apply(df_train,2,function(x){sum(is.na(x))}))
missing_val=sum(missing_val)
missing_val

#Finding missing value in test data
missing_val=data.frame(missing_val=apply(df_test,2,function(x){sum(is.na(x))}))
missing_val=sum(missing_val)
missing_val

#correlations in train data
#convert factor to int
df_train$target=as.numeric(df_train$target)
train_correlation=cor(df_train[,c(2:202)])
train_correlation

#we can observe that correlation between train attributes is very small

#correlations in test data
test_correlation=cor(df_test[,c(2:201)])
test_correlation

#we can observe that correlation between test attributes is very small.

#feature engineering- performing some feature engineering on datasets
#variable importance is used to see top features in dataset based on mean decreases gini.
#Building a simple model to find features which ae important

#split the training data using simple random sampling
train_index=sample(1:nrow(df_train),0.75*nrow(df_train))
train_data=df_train[train_index,]
valid_data=df_train[-train_index]
#dimension of train and validation data
dim(train_data)
dim(valid_data)

#Random Forest Classifier
set.seed(2732)
#convert int to factor
train_data$target=as.factor(train_data$target)
#setting the mtry
mtry=floor(sqrt(200))
#setting unegrid
tuneGrid=expand.grid(.mtry=mtry)

#fitting the random forest
RF=randomForest(target~.,train_data[,-c(1)],mtry=mtry,ntree=10,importance=TRUE)

#predict test data using random forest model
RF_predictions=predict(RF,df_test)

#writing back to desk
df_Finalsubmission=data.frame(ID_code=df_test$ID_code,Predicted=RF_predictions)
write.csv(df_Finalsubmission,'submission-R.csv',row.names = F)
head(df_Finalsubmission)
