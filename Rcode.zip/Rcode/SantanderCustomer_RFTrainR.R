#clean r env
rm(list = ls())
#setwd
setwd("D:/Rpractice")
library(randomForest)
library(DataCombine)
library(caret)

#loading data
df_train = read.csv("train.csv",header = T,sep=",")

#split the training data using simple random sampling
train_index=sample(1:nrow(df_train),0.75*nrow(df_train))
train_data=df_train[train_index,]
valid_data=df_train[-train_index,]
#dimension of train and validation data
dim(train_data)
dim(valid_data)

#Random Forest Classifier
set.seed(2732)
#convert int to factor
train_data$target=as.factor(train_data$target)
#setting the mtry
mtry=floor(sqrt(200))
#setting unegrid
tuneGrid=expand.grid(.mtry=mtry)

#fitting the random forest
RF=randomForest(target~.,train_data[,-c(1)],mtry=mtry,ntree=10,importance=TRUE)

#predict test data using random forest model
RF_predictions=predict(RF,valid_data[,-2])

#Evaluate the performance of classification model
confmatrix_RF=table(valid_data$target,RF_predictions)
confusionMatrix(confmatrix_RF)

#calculate FNR
#FN=149
#TP=163
FNR=FN/FN+TP
FNR=(149)/(149+163)
FNR
#accuracy=89.88, FNR=47.77
