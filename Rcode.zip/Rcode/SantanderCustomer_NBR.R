#clean r env
rm(list = ls())
#setwd
setwd("D:/Rpractice")
library(e1071)
library(DataCombine)
library(caret)
#installing mlr library
library(mlr)

#loading data
df_train = read.csv("train.csv",header = T,sep=",")

#spliting the train data
set.seed(689)
train.index=sample(1:nrow(df_train),0.8*nrow(df_train))
train.data=df_train[train.index,]
#validation data
valid.data=df_train[-train.index,]
#dimension of train data
dim(train.data)
dim(valid.data)
#target classes in train data
table(train.data$target)
table(valid.data$target)

#Create a classification task for learning on df_train dataset and target feature
task=makeClassifTask(data=df_train,target = "target")

#Intialize the Naive Bayes Classifier
selected_model=makeLearner("classif.naiveBayes")

#Train the model
NB_mlr=train(selected_model,task)

#Read the model learned
NB_mlr$learner.model

#Predict on the valid datase without passing target feature(which is need to be predicted)
prediction_mlr=as.data.frame(predict(NB_mlr,newdata=valid.data[-2]))

#Confusion matrix to check the accuracy
conf_matrix=table(observed=(prediction_mlr[,1]),predicted=valid.data$target)
confusionMatrix(conf_matrix)

#Accuracy=15.33
#FNR=83.25
#False negative rate
#FNR=FN/(FN+TP)taken values from confusion matrix
FNR=29911/(29911+6015)
FNR