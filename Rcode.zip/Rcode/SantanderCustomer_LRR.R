#clean r env
rm(list = ls())
#setwd
setwd("D:/Rpractice")
library(e1071)
library(DataCombine)
library(caret)

#loading data
df_train = read.csv("train.csv",header = T,sep=",")

#spliting the train data
set.seed(689)
train.index=sample(1:nrow(df_train),0.8*nrow(df_train))
train.data=df_train[train.index,]
#validation data
valid.data=df_train[-train.index,]
#dimension of train data
dim(train.data)
dim(valid.data)
#target classes in train data
table(train.data$target)
table(valid.data$target)

#Training and validation dataset
#Training dataset
X_t=as.matrix(train.data[,-c(1,2)])
Y_t=as.matrix(train.data$target)

#Validation dataset
X_v=as.matrix(valid.data[,-c(1,2)])
Y_v=as.matrix(valid.data$target)

#Building logistic regression model
set.seed(667)
lr_model=glmnet(X_t,Y_t,family = "binomial")
summary(lr_model)

#Cross validation prediction
set.seed(8909)
cv_lr=cv.glmnet(X_t,Y_t,family="binomial",type.measure = "class")
cv_lr

#MOdel performace on validation dataset
set.seed(5363)
cv_predict.lr=predict(cv_lr,X_v,s="lambda.min",type="class")
cv_predict.lr

#confusion matrix
set.seed(689)
#Actual target value
target=valid.data$target
#convert to factor
target=as.factor(target)
#predicted target variable
#convert to factor
cv_predict.lr=as.factor(cv_predict.lr)
confusionMatrix(data = cv_predict.lr,reference = target)

#accuracy = 91.39
#FNR= 73.19
#false negative rate
#FNR=FN/FN+TP
FNR=2982/(2982+1092)
FNR